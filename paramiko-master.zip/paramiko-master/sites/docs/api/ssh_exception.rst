Exceptions
==========

.. automodule:: paramiko.ssh_exception
